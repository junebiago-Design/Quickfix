// ══════════════════════════════════════════════
//  KANBAN (TASKS / DEALS / STAGES) — js/modules/kanban.js
//  Part of app.js module split.
//  Depends on js/api.js (data layer) and other
//  js/modules/*.js files being loaded first per
//  index.html script order. Shares the global
//  scope (classic scripts).
// ══════════════════════════════════════════════

// ══════════════════════════════════════════════
//  KANBAN — with stage dropdown + vertical stacking
// ══════════════════════════════════════════════

let dragDealId = null;
let draggingStageKey = null;
let currentDealNotesId = null;
let editingStageKey = null;
let selectedStageColor = '#4f8ef7';
let stageRoleRows = [];
let dealContactRows = [];
const STAGE_COLOR_PALETTE = ['#4f8ef7', '#a78bfa', '#f5c842', '#3ecf8e', '#f56565', '#fb923c', '#38bdf8', '#ec4899'];

// ── Stage permissions: VISIBILITY vs ACTION permission ──
// Every stage is always visible to everyone, in the same order, with all its
// task cards. What differs per role is whether specific actions — Grab
// (move out), Drop (move in), Edit, Comment, Revision — are allowed while a
// task sits in that stage. All of the actual permission logic (including
// role inheritance) now lives in permissions.js — this file only calls it.

// Reads a stage's LEGACY role list, falling back to the older single `role`
// field for stages saved before multi-role support existed. Still used as
// a migration source by permissions.js#getStagePermissionsMap() and by the
// stage editor's "visible to" role rows, which are unrelated to the new
// granular action permissions.
function getStageRoles(s) {
    return (s?.roles && s.roles.length) ? s.roles : (s?.role ? [s.role] : []);
}

// The built-in System Administrator role (and the default admin identity)
// bypasses every stage restriction — always full access everywhere.
function isKanbanSuperuser() {
    return currentUser.role === 'admin' || currentUser.role === SYSTEM_ROLE_ID;
}

// Gate for showing the ⚙ Permissions button on a stage column — only
// Administrators (and System Administrators) manage stage permissions.
// Falls back to isKanbanSuperuser() if roles.js's isAdministrator() isn't
// loaded yet, so this never throws.
function isAdministratorRoleSafe() {
    if (typeof isAdministrator === 'function') return isAdministrator();
    return isKanbanSuperuser();
}

// Legacy coarse check, kept so any call site that hasn't been migrated to
// a specific canGrab/canDrop/canEdit/canComment/canRevision check still
// works: "can the user do ANYTHING in this stage?" Delegates to the
// permission engine in permissions.js.
function canActOnStage(stageOrKey) {
    if (isKanbanSuperuser()) return true;
    if (typeof canActOnStageGranular === 'function') return canActOnStageGranular(stageOrKey);
    // permissions.js not loaded yet — fail open on legacy role-list stages
    // exactly like the pre-RBAC behavior did.
    const stage = typeof stageOrKey === 'string' ? stages.find(s => s.key === stageOrKey) : stageOrKey;
    if (!stage) return true;
    const r = getStageRoles(stage);
    return !r.length || r.includes(currentUser.role);
}

function openDealModal(id, defaultStage) {
    if (isEmployee()) return;
    const d = id ? deals.find(x => x.id === id) : null;
    // ✅ Edit permission is now stage-specific (canEdit), not the old
    // coarse canActOnStage. A user without Edit on this stage can still
    // open the task — just in read-only View mode instead.
    if (d && !isKanbanSuperuser() && typeof canEdit === 'function' && !canEdit(d.stage)) {
        openDealViewOnly(id);
        return;
    }
    editingId = id || null;
    document.getElementById('deal-modal-title').textContent = d ? 'Edit Task' : 'Add Task';
    document.getElementById('d-title').value = d?.title || '';
    document.getElementById('d-desc').value = d?.desc || '';
    document.getElementById('d-due').value = d?.due || new Date().toISOString().slice(0, 10);
    document.getElementById('d-priority').value = d?.priority || 'medium';
    populateDepartmentSelect(document.getElementById('d-department'), d?.department || '');
    populateRoleSelect(document.getElementById('d-role'), d?.role || '');

    const stageSel = document.getElementById('d-stage');
    stageSel.innerHTML = stages.map(s => `<option value="${s.key}">${s.label}</option>`).join('');
    stageSel.value = d?.stage || defaultStage || stages[0]?.key || '';

    // ✅ Support multiple "Assign To" employees per task. Falls back to the
    // older single `contactId` field for tasks saved before this feature
    // existed.
    dealContactRows = (d?.contactIds && d.contactIds.length) ? [...d.contactIds] : (d?.contactId ? [d.contactId] : []);
    renderDealContactRows();

    openModal('deal-modal');
}

// ✅ Renders one "Assign To" <select> per entry in dealContactRows, each
// replicating the original single Assign To dropdown, plus a remove button.
// An empty dealContactRows list means the task isn't assigned to anyone.
function renderDealContactRows() {
    const el = document.getElementById('d-contact-list');
    if (!el) return;

    if (!dealContactRows.length) {
        el.innerHTML = `<div style="font-size:0.8rem;color:var(--text3);padding:4px 0;">Not assigned to anyone — click "+ Add Assign To" to assign.</div>`;
        return;
    }

    el.innerHTML = dealContactRows.map((val, i) => `
      <div style="display:flex;gap:6px;align-items:center;">
        <select onchange="updateDealContactRow(${i}, this.value)" style="flex:1;">
          <option value="">— Select —</option>
          ${contacts.map(c => `<option value="${c.id}" ${val === c.id ? 'selected' : ''}>${c.fname} ${c.lname}</option>`).join('')}
          ${val && !contacts.find(c => c.id === val) ? `<option value="${val}" selected>${val} (legacy)</option>` : ''}
        </select>
        <button type="button" class="icon-btn" title="Remove this assignee" onclick="removeDealContactRow(${i})">✕</button>
      </div>
    `).join('');
}

function addDealContactRow() {
    dealContactRows.push('');
    renderDealContactRows();
}

function removeDealContactRow(i) {
    dealContactRows.splice(i, 1);
    renderDealContactRows();
}

function updateDealContactRow(i, value) {
    dealContactRows[i] = value;
}

function saveDeal() {
    if (isEmployee()) return;
    const title = document.getElementById('d-title').value.trim();
    const due = document.getElementById('d-due').value;
    if (!title || !due) { toast('Task title and due date are required.', 'error'); return; }

    const oldDeal = editingId ? deals.find(d => d.id === editingId) : null;
    const oldStage = oldDeal?.stage;

    const obj = {
        id: editingId || uid(),
        title,
        desc: document.getElementById('d-desc').value.trim(),
        due,
        priority: document.getElementById('d-priority').value,
        department: document.getElementById('d-department').value,
        role: document.getElementById('d-role').value,
        contactIds: [...new Set(dealContactRows.filter(Boolean))],
        stage: document.getElementById('d-stage').value,
        createdAt: editingId ? (oldDeal?.createdAt || new Date().toISOString()) :
            new Date().toISOString(),
    };

    if (editingId) {
        deals = deals.map(d => d.id === editingId ? obj : d);
        logActivity(`Updated task <strong>${title}</strong>`, 'yellow');
        toast('Task updated.', 'success');
    } else {
        deals.unshift(obj);
        logActivity(`Added task <strong>${title}</strong>`, 'purple');
        toast('Task added.', 'success');
    }
    saveAll();
    closeModal('deal-modal');
    // Only the stage(s) actually touched need to re-render — the one it's
    // in now, and (if editing moved it) the one it used to be in.
    renderStageColumn(obj.stage);
    if (oldStage && oldStage !== obj.stage) renderStageColumn(oldStage);
    updateBadges();
    if (currentPage === 'dashboard') renderDashboard();
}

function deleteDeal(id) {
    if (isEmployee()) return;
    const d = deals.find(x => x.id === id);
    if (d && !isKanbanSuperuser() && typeof canEdit === 'function' && !canEdit(d.stage)) {
        toast('You do not have permission to delete tasks in this stage.', 'error');
        return;
    }
    confirmDelete(`Delete task "${d?.title}"?`, () => {
        deals = deals.filter(x => x.id !== id);
        logActivity(`Deleted task <strong>${d?.title}</strong>`, 'red');
        saveAll();
        toast('Task deleted.');
        if (d) renderStageColumn(d.stage); else renderKanban();
        updateBadges();
        if (currentPage === 'dashboard') renderDashboard();
    });
}

function moveDealStage(dealId, newStage) {
    const deal = deals.find(d => d.id === dealId);
    if (!deal) return;
    if (deal.stage === newStage) return;
    const superuser = isKanbanSuperuser();
    const grabOk = superuser || typeof canGrab !== 'function' || canGrab(deal.stage);
    const dropOk = superuser || typeof canDrop !== 'function' || canDrop(newStage);
    if (!grabOk || !dropOk) {
        toast('You do not have permission to move this task.', 'error');
        renderStageColumn(deal.stage); // reset the dropdown back to its actual value
        return;
    }

    const oldStage = deal.stage;
    deal.stage = newStage;

    const oldLabel = stages.find(s => s.key === oldStage)?.label || oldStage;
    const newLabel = stages.find(s => s.key === newStage)?.label || newStage;

    logActivity(`Moved task <strong>${deal.title}</strong> from ${oldLabel} → ${newLabel}`, 'orange');
    saveAll();

    renderStageColumn(oldStage);
    renderStageColumn(newStage);
    updateBadges();
    if (currentPage === 'dashboard') renderDashboard();
    toast(`Moved to ${newLabel}`, 'success');
}

function openStageModal(key) {
    if (isEmployee()) return;
    editingStageKey = key || null;
    const s = key ? stages.find(x => x.key === key) : null;
    document.getElementById('stage-modal-title').textContent = s ? 'Edit Stage' : 'Add Stage';
    document.getElementById('stage-name').value = s?.label || '';
    document.getElementById('stage-final').checked = !!s?.final;

    // ✅ Support multiple "visible to" roles per stage. Falls back to the
    // older single `role` field for stages saved before this feature existed.
    stageRoleRows = (s?.roles && s.roles.length) ? [...s.roles] : (s?.role ? [s.role] : []);
    renderStageRoleRows();

    selectedStageColor = s?.color || STAGE_COLOR_PALETTE[stages.length % STAGE_COLOR_PALETTE.length];
    renderStageColorPicker();

    const delBtn = document.getElementById('stage-delete-btn');
    delBtn.style.display = s ? '' : 'none';

    // ✅ RBAC Phase 5 — the ⚙ Permissions button (optional markup, see
    // rbac-modals.html block 6) only makes sense for an existing stage.
    const permBtn = document.getElementById('stage-permissions-btn');
    if (permBtn) permBtn.style.display = s ? '' : 'none';

    openModal('stage-modal');
}

function renderStageColorPicker() {
    const el = document.getElementById('stage-color-picker');
    el.innerHTML = STAGE_COLOR_PALETTE.map(c => `
      <div class="color-swatch ${c === selectedStageColor ? 'selected' : ''}" style="background:${c}" onclick="pickStageColor('${c}')"></div>
    `).join('');
}

function pickStageColor(c) {
    selectedStageColor = c;
    renderStageColorPicker();
}

// ✅ Renders one role <select> per entry in stageRoleRows, each replicating
// the original single "Visible To Role" dropdown, plus a remove button.
// An empty stageRoleRows list means the stage is visible to all roles.
function renderStageRoleRows() {
    const el = document.getElementById('stage-role-list');
    if (!el) return;

    if (!stageRoleRows.length) {
        el.innerHTML = `<div style="font-size:0.8rem;color:var(--text3);padding:4px 0;">Visible to all roles — click "+ Add Role" to restrict.</div>`;
        return;
    }

    el.innerHTML = stageRoleRows.map((val, i) => `
      <div style="display:flex;gap:6px;align-items:center;">
        <select onchange="updateStageRoleRow(${i}, this.value)" style="flex:1;">
          <option value="">— Select Role —</option>
          ${roles.map(r => `<option value="${r.id}" ${val === r.id ? 'selected' : ''}>${r.name}</option>`).join('')}
          ${val && !roles.find(r => r.id === val) ? `<option value="${val}" selected>${val} (legacy)</option>` : ''}
        </select>
        <button type="button" class="icon-btn" title="Remove this role" onclick="removeStageRoleRow(${i})">✕</button>
      </div>
    `).join('');
}

function addStageRoleRow() {
    stageRoleRows.push('');
    renderStageRoleRows();
}

function removeStageRoleRow(i) {
    stageRoleRows.splice(i, 1);
    renderStageRoleRows();
}

function updateStageRoleRow(i, value) {
    stageRoleRows[i] = value;
}

// For a stage being edited, works out which roles are losing action access
// (drag/drop/edit) under the new roles list, then counts how many tasks in
// that stage are currently assigned to users holding each of those roles.
// Returns { roleId: Set(taskId) } for roles that actually have tasks at risk.
function computeStageRoleRemovalImpact(stageKey, removedRoles) {
    const impact = {};
    removedRoles.forEach(r => { impact[r] = new Set(); });
    deals.filter(d => d.stage === stageKey).forEach(d => {
        const contactIds = (d.contactIds && d.contactIds.length) ? d.contactIds : (d.contactId ? [d.contactId] : []);
        contactIds.forEach(cid => {
            const contact = contacts.find(c => c.id === cid);
            if (contact && removedRoles.includes(contact.role)) impact[contact.role].add(d.id);
        });
    });
    return impact;
}

function saveStage() {
    if (isEmployee()) return;
    const label = document.getElementById('stage-name').value.trim();
    if (!label) { toast('Stage name is required.', 'error'); return; }
    const final = document.getElementById('stage-final').checked;
    const newRoles = [...new Set(stageRoleRows.filter(Boolean))];

    if (editingStageKey) {
        const s = stages.find(x => x.key === editingStageKey);
        const oldRoles = getStageRoles(s);
        const allRoleIds = roles.map(r => r.id);
        // Empty roles list means "everyone" — expand to every known role so
        // narrowing from "everyone" down to a subset is detected too.
        const priorAllowed = oldRoles.length ? oldRoles : allRoleIds;
        const nextAllowed = newRoles.length ? newRoles : allRoleIds;
        const removedRoles = priorAllowed.filter(r => !nextAllowed.includes(r));

        if (removedRoles.length) {
            const impact = computeStageRoleRemovalImpact(editingStageKey, removedRoles);
            const impactedEntries = removedRoles
                .map(r => ({ roleId: r, count: impact[r].size }))
                .filter(e => e.count > 0);

            if (impactedEntries.length) {
                const stageLabel = s?.label || label;
                const roleNames = impactedEntries.map(e => getRoleName(e.roleId)).join(', ');
                const lines = impactedEntries
                    .map(e => `${e.count} task${e.count === 1 ? '' : 's'} assigned to users with the ${getRoleName(e.roleId)} role.`)
                    .join('\n');
                confirmDelete(
                    `Role Restriction Warning\n\n` +
                    `You removed access for ${roleNames} from the "${stageLabel}" stage.\n\n` +
                    `${lines}\n\n` +
                    `Those users will still be able to see the stage and tasks, but they will no longer be able to drag, edit, or change those tasks while they remain in this stage.`,
                    () => commitStageSave(label, final, newRoles)
                );
                return;
            }
        }
    }

    commitStageSave(label, final, newRoles);
}

function commitStageSave(label, final, stageRoles) {
    const wasEditing = !!editingStageKey;
    if (editingStageKey) {
        const s = stages.find(x => x.key === editingStageKey);
        if (s) { s.label = label; s.color = selectedStageColor; s.final = final; s.roles = stageRoles; delete s.role; }
        logActivity(`Renamed board stage to <strong>${label}</strong>`, 'yellow');
        toast('Stage updated.', 'success');
    } else {
        const key = 'stage_' + uid();
        stages.push({ key, label, color: selectedStageColor, final, roles: stageRoles });
        logActivity(`Added board stage <strong>${label}</strong>`, 'purple');
        toast('Stage added.', 'success');
    }
    saveAll();
    closeModal('stage-modal');
    const savedKey = editingStageKey;
    editingStageKey = null;
    // Editing an existing stage only changes that one column (label,
    // color, roles) — a brand new stage changes the board's structure
    // (a whole new column appears), which still needs the full render.
    if (wasEditing) renderStageColumn(savedKey); else renderKanban();
}

function deleteStageFromModal() {
    if (!editingStageKey) return;
    if (stages.length <= 1) { toast('You need at least one stage.', 'error'); return; }
    const s = stages.find(x => x.key === editingStageKey);
    const fallback = stages.find(x => x.key !== editingStageKey);
    confirmDelete(`Delete stage "${s?.label}"? Tasks in it will move to "${fallback.label}".`, () => {
        deals.forEach(d => { if (d.stage === editingStageKey) d.stage = fallback.key; });
        stages = stages.filter(x => x.key !== editingStageKey);
        saveAll();
        toast('Stage deleted.');
        closeModal('stage-modal');
        editingStageKey = null;
        renderKanban();
        updateBadges();
        if (currentPage === 'dashboard') renderDashboard();
    });
}

// ══════════════════════════════════════════════
//  Stage Permission Modal (openStagePermissionModal, saveStagePermissions,
//  etc.) moved to js/modules/modals.js.
//  Read-only Task Viewer (openDealViewOnly) moved to js/modules/deals.js.
//  Both still share this file's globals (stages, roles, deals, editingId,
//  openModal/closeModal, toast, confirmDelete, logActivity, saveAll,
//  renderKanban) via the classic-script global scope — no behavior
//  changed, only file location. Make sure index.html loads modals.js and
//  deals.js after kanban.js.
// ══════════════════════════════════════════════

// Reads the employee currently selected in the topbar dropdown (used to
// filter the Task/Deal board below). Returns '' when nothing is selected.
function getTopbarFilterEmployeeId() {
    const dropdown = document.getElementById('topbar-employee-select');
    return dropdown ? dropdown.value : '';
}

// Extracted from renderKanban() so the summary chip (Total/Completed/
// Overdue/Filtered-by) can be refreshed on its own — its counts depend
// on ALL deals, so any single-stage change still needs this, but it's
// cheap (a few .filter() passes + one innerHTML write) compared to
// rebuilding the whole board.
function renderPipelineSummary() {
    const isSuperuser = isKanbanSuperuser();
    const getDealContactIds = d => (d.contactIds && d.contactIds.length) ? d.contactIds : (d.contactId ? [d.contactId] : []);
    const filterEmployeeId = getTopbarFilterEmployeeId();
    const visibleDeals = (filterEmployeeId && !isSuperuser) ? deals.filter(d => getDealContactIds(d).includes(filterEmployeeId)) : deals;

    const todayStr = new Date().toISOString().slice(0, 10);
    const total = visibleDeals.length;
    const finalKeys = new Set(stages.filter(s => s.final).map(s => s.key));
    const completed = visibleDeals.filter(d => finalKeys.has(d.stage)).length;
    const overdue = visibleDeals.filter(d => !finalKeys.has(d.stage) && d.due < todayStr).length;

    const filterContact = (filterEmployeeId && !isSuperuser) ? contacts.find(c => c.id === filterEmployeeId) : null;
    const filterChip = filterContact ? `
    <div class="pipe-chip" style="background:var(--accent-soft, rgba(99,102,241,0.12));">
      <span>Filtered by</span>
      <span class="pipe-chip-val" style="display:flex;align-items:center;gap:6px;">
        👤 ${filterContact.fname} ${filterContact.lname}
        <button type="button" onclick="clearTopbarEmployeeFilter()" title="Clear filter"
          style="background:none;border:none;cursor:pointer;color:var(--text2);font-size:0.85rem;line-height:1;padding:0;">✕</button>
      </span>
    </div>` : '';

    const el = document.getElementById('pipeline-summary');
    if (el) el.innerHTML = `
    <div class="pipe-chip"><span>Total Tasks</span><span class="pipe-chip-val">${total}</span></div>
    <div class="pipe-chip"><span>Completed</span><span class="pipe-chip-val">${completed}</span></div>
    <div class="pipe-chip"><span>Overdue</span><span class="pipe-chip-val">${overdue}</span></div>
    ${filterChip}
  `;
}

// Shared context every column needs, computed once per render (full or
// scoped) rather than recomputed per-stage inside a .map().
function buildKanbanRenderCtx() {
    const employee = isEmployee();
    const isSuperuser = isKanbanSuperuser();
    const getDealContactIds = d => (d.contactIds && d.contactIds.length) ? d.contactIds : (d.contactId ? [d.contactId] : []);
    const filterEmployeeId = getTopbarFilterEmployeeId();
    const visibleDeals = (filterEmployeeId && !isSuperuser) ? deals.filter(d => getDealContactIds(d).includes(filterEmployeeId)) : deals;
    const visibleStages = employee ? stages.filter(s => !s.final) : stages;
    return { employee, isSuperuser, visibleDeals, visibleStages, stageOptionsForDropdown: visibleStages };
}

// The INNER content of one column (header + cards + add-task button) —
// everything EXCEPT the outer .kanban-col wrapper itself, so a scoped
// update (renderStageColumn) can drop this into an existing wrapper
// without disturbing its drag/drop attributes, and a full render
// (renderKanban) can wrap it fresh for every stage.
function stageColumnInnerHTML(stage, ctx) {
    const { employee, isSuperuser, visibleDeals, stageOptionsForDropdown } = ctx;
    const stageDeals = visibleDeals.filter(d => d.stage === stage.key);
    const myGrab = isSuperuser || typeof canGrab !== 'function' || canGrab(stage);
    const myDrop = isSuperuser || typeof canDrop !== 'function' || canDrop(stage);
    const myEdit = isSuperuser || typeof canEdit !== 'function' || canEdit(stage);
    const permIcons = [
        myGrab ? '' : '<span title="No Grab permission — cannot move tasks out of this stage">↗️🚫</span>',
        myDrop ? '' : '<span title="No Drop permission — cannot move tasks into this stage">↘️🚫</span>',
        myEdit ? '' : '<span title="No Edit permission — tasks open read-only in this stage">✎🚫</span>',
    ].filter(Boolean).join(' ');
    const permBadge = permIcons ? `<span style="margin-left:4px;display:inline-flex;gap:3px;font-size:0.7rem;">${permIcons}</span>` : '';

    return `
    <div class="kanban-col-header" ${employee ? '' : `draggable="true" ondragstart="onColDragStart(event,'${stage.key}')" ondragend="onColDragEnd(event)"`}>
      <div style="display:flex;align-items:center;flex-wrap:wrap;">
        ${employee ? '' : `<span class="col-drag-handle" title="Drag to reorder">⠿</span>`}
        <span class="col-dot" style="background:${stage.color}"></span>${stage.label}
        ${permBadge}
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <span class="col-count">${stageDeals.length}</span>
        ${employee ? '' : `<button class="icon-btn" style="width:22px;height:22px;font-size:0.7rem;" onclick="openStageModal('${stage.key}')" title="Edit stage">✎</button>`}
        ${(employee || !isAdministratorRoleSafe()) ? '' : `<button class="icon-btn" style="width:22px;height:22px;font-size:0.7rem;" onclick="openStagePermissionModal('${stage.key}')" title="Permissions">⚙</button>`}
      </div>
    </div>
    <div class="kanban-cards" data-stage="${stage.key}"
      ondragover="onDragOver(event,'${stage.key}')" ondrop="onDrop(event,'${stage.key}')" ondragleave="onDragLeave(event)">
      ${stageDeals.map(d => dealCardHTML(d, stage, employee, stageOptionsForDropdown)).join('')}
    </div>
    ${(employee || !(myDrop || myEdit)) ? '' : `<button class="kanban-add-btn" onclick="openDealModal(null,'${stage.key}')">+ Add task</button>`}
  `;
}

// Full outer <div class="kanban-col">...</div> for one stage — used only
// by the full-board render below.
function stageColumnHTML(stage, ctx) {
    const { employee } = ctx;
    return `
      <div class="kanban-col" data-stage-key="${stage.key}"
        ${employee ? '' : `ondragover="onColDragOver(event,'${stage.key}')" ondrop="onColDrop(event,'${stage.key}')" ondragleave="onColDragLeave(event)"`}>
        ${stageColumnInnerHTML(stage, ctx)}
      </div>
    `;
}

// Re-renders ONE stage column in place — used after any change that
// only affects a single stage's cards/count/permissions (adding,
// editing, deleting, or moving a task; saving that stage's permissions;
// editing that stage's label/color/roles). Falls back to the full
// renderKanban() if the column isn't in the DOM yet (first load) or if
// the stage no longer exists (e.g. it was just deleted) — both genuinely
// need a full rebuild.
function renderStageColumn(stageKey) {
    const stage = stages.find(s => s.key === stageKey);
    const col = document.querySelector(`.kanban-col[data-stage-key="${stageKey}"]`);
    if (!stage || !col) { renderKanban(); return; }

    const ctx = buildKanbanRenderCtx();
    // Employee view hides "final" stages entirely — if this stage isn't
    // in the currently-visible set for this viewer, the column shouldn't
    // exist at all, which is a structural change, not a scoped update.
    if (!ctx.visibleStages.includes(stage)) { renderKanban(); return; }

    col.innerHTML = stageColumnInnerHTML(stage, ctx);
    renderPipelineSummary();
}

function renderKanban() {
    const ctx = buildKanbanRenderCtx();
    const { employee, visibleStages } = ctx;

    renderPipelineSummary();

    const addBtn = document.getElementById('deals-add-btn');
    if (addBtn) addBtn.style.display = employee ? 'none' : '';

    const board = document.getElementById('kanban-board');
    board.innerHTML = visibleStages.map(stage => stageColumnHTML(stage, ctx)).join('') + (employee ? '' : `
      <div class="kanban-col kanban-col-add">
        <button class="kanban-add-stage-btn" onclick="openStageModal()">+ Add Stage</button>
      </div>
    `);

    const boardEl = document.getElementById('kanban-board');
    const hint = document.querySelector('.kanban-scroll-hint');
    if (boardEl && window.innerWidth > 768) {
        const hasOverflow = boardEl.scrollWidth > boardEl.clientWidth;
        if (hasOverflow) {
            boardEl.classList.add('scrollable');
            if (hint) hint.classList.add('visible');
        } else {
            boardEl.classList.remove('scrollable');
            if (hint) hint.classList.remove('visible');
        }
    } else {
        if (boardEl) boardEl.classList.remove('scrollable');
        if (hint) hint.classList.remove('visible');
    }
}

function dealCardHTML(d, stage, employee, stageOptions) {
    const dealContactIds = (d.contactIds && d.contactIds.length) ? d.contactIds : (d.contactId ? [d.contactId] : []);
    const cname = dealContactIds.map(id => getContactName(id)).filter(Boolean).join(', ');
    const todayStr = new Date().toISOString().slice(0, 10);
    const isOverdue = !stage.final && d.due < todayStr;

    // ✅ Granular stage permissions: Grab (move this task out), Drop (move
    // another task in), Edit (edit/delete details). Visibility of the card
    // itself is never affected by any of these — only these interactions.
    const superuser = isKanbanSuperuser();
    const canGrabHere = superuser || typeof canGrab !== 'function' || canGrab(stage);
    const canEditHere = superuser || typeof canEdit !== 'function' || canEdit(stage);
    const canCommentHere = superuser || typeof canComment !== 'function' || canComment(stage);
    const canRevisionHere = superuser || typeof canRevision !== 'function' || canRevision(stage);
    // Kept for the draggable attribute / card-level affordances that don't
    // care which specific permission applies, just "is this card locked".
    const canManage = canGrabHere || canEditHere;

    // Dropdown can only offer moving into stages the user has Drop on
    // (plus the task's current stage, so the select always has a valid
    // selected value even when the user can't Grab it out).
    const stageOpts = stageOptions
        .filter(s => s.key === d.stage || superuser || typeof canDrop !== 'function' || canDrop(s))
        .map(s => `<option value="${s.key}" ${s.key === d.stage ? 'selected' : ''}>${s.label}</option>`)
        .join('');

    const dropdownHtml = `
    <select class="deal-stage-select" onchange="moveDealStage('${d.id}', this.value)"
            title="${canGrabHere ? 'Move to another stage' : "You don't have Grab permission in this stage"}"
            ${canGrabHere ? '' : 'disabled'}>
      ${stageOpts}
    </select>
  `;

    const dealNotes = notes.filter(n => n.dealId === d.id);

    // Only the essentials on the card face — description, department, and
    // role are still on the full task (Edit/View), just not repeated here.
    // Assignee is shown as initials only (title attribute carries the full
    // name) so it sits on the same line as due date/priority instead of
    // its own row.
    const assigneeInitials = dealContactIds.slice(0, 3).map(id => initials(getContactName(id) || '')).filter(Boolean);
    const assigneeHTML = assigneeInitials.length ? `
      <span class="deal-card-assignee" title="${cname}">
        👤 ${assigneeInitials.join(' ')}${dealContactIds.length > 3 ? ` +${dealContactIds.length - 3}` : ''}
      </span>` : '';

    return `
    <div class="deal-card ${canEditHere ? '' : 'deal-card-readonly'}" draggable="${canGrabHere ? 'true' : 'false'}"
      data-id="${d.id}"
      ${canGrabHere ? `
      ondragstart="onDragStart(event,'${d.id}')" ondragend="onDragEnd(event)"
      ondragover="onCardDragOver(event,'${d.id}','${stage.key}')" ondrop="onCardDrop(event,'${d.id}','${stage.key}')"` : ''}
      ${canManage ? '' : `title="You don't have permission to drag or edit tasks in this stage"`}>
      <div class="deal-card-title">${d.title} ${canEditHere ? '' : `<span title="Read-only in this stage" style="font-size:0.7rem;">🔒</span>`}</div>

      <div class="deal-card-meta">
        <span class="task-due ${isOverdue?'overdue':''}" style="font-family:'DM Mono',monospace;">📅 ${fmtDate(d.due)}</span>
        ${priorityBadge(d.priority)}
        ${assigneeHTML}
      </div>

      <div class="deal-card-meta deal-card-meta-actions">
        ${dropdownHtml}
        ${employee ? '' : canEditHere ? `
        <div class="deal-actions">
          <button class="icon-btn" style="width:24px;height:24px;font-size:0.75rem;" onclick="openDealModal('${d.id}')" title="Edit">✎</button>
          <button class="icon-btn danger" style="width:24px;height:24px;font-size:0.75rem;" onclick="deleteDeal('${d.id}')" title="Delete">🗑</button>
        </div>` : `
        <div class="deal-actions">
          <button class="icon-btn" style="width:24px;height:24px;font-size:0.75rem;" onclick="openDealViewOnly('${d.id}')" title="View (read-only — you lack Edit permission in this stage)">👁</button>
        </div>`}
      </div>

      <button class="deal-notes-toggle deal-card-notes-compact" onclick="openDealNotesModal('${d.id}')" title="View comments &amp; revisions">
        <span>💬 Notes</span>
        <span class="deal-notes-count">${dealNotes.length}</span>
      </button>
    </div>
  `;
}

// dealNotes list rendering — shared by the notes-row toggle and the deal
// notes modal. Groups items with a Comment/Revision badge per Phase 6/9.
function dealNotesListHTML(dealNotes, employee) {
    if (!dealNotes.length) {
        return `<div class="deal-notes-empty">No comments or revisions linked to this task yet.</div>`;
    }
    return dealNotes.map(n => `
    <div class="deal-note-item">
      <div class="deal-note-item-main" onclick="openNoteModal('${n.id}')">
        <div class="deal-note-item-title">${n.title} ${typeof noteTypeBadge === 'function' ? noteTypeBadge(n) : ''}</div>
        <div class="deal-note-item-preview">${n.content.slice(0, 70)}${n.content.length > 70 ? '…' : ''}</div>
      </div>
      ${employee ? '' : `
      <div class="deal-note-item-actions">
        <button class="icon-btn" style="width:22px;height:22px;font-size:0.65rem;" onclick="event.stopPropagation();openNoteModal('${n.id}')" title="Edit">✎</button>
        <button class="icon-btn danger" style="width:22px;height:22px;font-size:0.65rem;" onclick="event.stopPropagation();deleteNote('${n.id}')" title="Delete">🗑</button>
      </div>`}
    </div>
  `).join('');
}

function openDealNotesModal(dealId) {
    currentDealNotesId = dealId;
    const deal = deals.find(d => d.id === dealId);
    document.getElementById('deal-notes-modal-title').textContent = deal ? `Notes — ${deal.title}` : 'Notes';
    renderDealNotesModalList();
    openModal('deal-notes-modal');
}

// Renders the deal notes modal. If the modal markup has separate
// #deal-notes-modal-list-comments / #deal-notes-modal-list-revisions
// containers, renders each type into its own tab; otherwise falls back
// to a single combined list in #deal-notes-modal-list (both types
// together, each row still carries its Comment/Revision badge).
function renderDealNotesModalList() {
    if (!currentDealNotesId) return;
    const employee = isEmployee();
    const commentsEl = document.getElementById('deal-notes-modal-list-comments');
    const revisionsEl = document.getElementById('deal-notes-modal-list-revisions');

    if (commentsEl || revisionsEl) {
        if (commentsEl) commentsEl.innerHTML = dealNotesListHTML(getDealComments(currentDealNotesId), employee);
        if (revisionsEl) revisionsEl.innerHTML = dealNotesListHTML(getDealRevisions(currentDealNotesId), employee);
        return;
    }

    const listEl = document.getElementById('deal-notes-modal-list');
    if (!listEl) return;
    const dealNotes = notes.filter(n => n.dealId === currentDealNotesId);
    listEl.innerHTML = dealNotesListHTML(dealNotes, employee);
}

// ── Drag & Drop helpers (task cards) ──

function onDragStart(e, id) {
    // ✅ Can't drag a task out of a stage the current user doesn't have
    // Grab permission on. The card's `draggable` attribute already
    // prevents this in supporting browsers; this is a defense-in-depth
    // backstop.
    const deal = deals.find(d => d.id === id);
    if (deal && !isKanbanSuperuser() && typeof canGrab === 'function' && !canGrab(deal.stage)) {
        e.preventDefault();
        return;
    }
    dragDealId = id;
    setTimeout(() => e.target.classList.add('dragging'), 0);
    document.getElementById('kanban-board')?.classList.add('dnd-active');
    e.dataTransfer.effectAllowed = 'move';
}

function onDragEnd(e) {
    e.target.classList.remove('dragging');
    document.querySelectorAll('.kanban-cards').forEach(c => c.classList.remove('drag-over'));
    document.querySelectorAll('.deal-card').forEach(c => c.classList.remove('drop-before', 'drop-after'));
    document.getElementById('kanban-board')?.classList.remove('dnd-active');
    dragDealId = null;
}

function onDragOver(e, stage) {
    if (draggingStageKey) return;
    // ✅ Can't drag into a stage the current user doesn't have Drop
    // permission on — skip preventDefault so the browser shows its native
    // "no drop" cursor instead of the drag-over highlight.
    if (stage && !isKanbanSuperuser() && typeof canDrop === 'function' && !canDrop(stage)) return;
    e.preventDefault();
    e.currentTarget.classList.add('drag-over');
}

function onDragLeave(e) {
    if (draggingStageKey) return;
    e.currentTarget.classList.remove('drag-over');
}

function onDrop(e, stage) {
    if (draggingStageKey) return;
    e.preventDefault();
    e.currentTarget.classList.remove('drag-over');
    if (!dragDealId) return;
    if (!isKanbanSuperuser() && typeof canDrop === 'function' && !canDrop(stage)) {
        toast("You don't have permission to move tasks into this stage.", 'error');
        dragDealId = null;
        return;
    }
    appendDealToStageEnd(dragDealId, stage);
    dragDealId = null;
}

// Hovering directly over an existing card — show an insertion line above/below it
function onCardDragOver(e, overId, stage) {
    if (draggingStageKey || !dragDealId || dragDealId === overId) return;
    if (stage && !isKanbanSuperuser() && typeof canDrop === 'function' && !canDrop(stage)) return;
    e.preventDefault();
    e.stopPropagation();
    const card = e.currentTarget;
    const rect = card.getBoundingClientRect();
    const before = e.clientY < (rect.top + rect.height / 2);
    document.querySelectorAll('.deal-card').forEach(c => c.classList.remove('drop-before', 'drop-after'));
    card.classList.add(before ? 'drop-before' : 'drop-after');
}

// Dropping directly onto an existing card — insert the dragged card before/after it
function onCardDrop(e, overId, stage) {
    if (draggingStageKey) return;
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.closest('.kanban-cards')?.classList.remove('drag-over');
    if (!dragDealId || dragDealId === overId) { dragDealId = null; return; }
    if (!isKanbanSuperuser() && typeof canDrop === 'function' && !canDrop(stage)) {
        toast("You don't have permission to move tasks into this stage.", 'error');
        dragDealId = null;
        return;
    }
    const before = e.currentTarget.classList.contains('drop-before');
    reorderDeal(dragDealId, overId, before, stage);
    dragDealId = null;
}

function reorderDeal(dealId, overId, before, stage) {
    const deal = deals.find(d => d.id === dealId);
    const overDeal = deals.find(d => d.id === overId);
    if (!deal || !overDeal) return;

    const oldStage = deal.stage;
    const changedStage = oldStage !== stage;
    deal.stage = stage;

    deals = deals.filter(d => d.id !== dealId);
    let idx = deals.findIndex(d => d.id === overId);
    if (idx === -1) idx = deals.length;
    if (!before) idx += 1;
    deals.splice(idx, 0, deal);

    if (changedStage) {
        const oldLabel = stages.find(s => s.key === oldStage)?.label || oldStage;
        const newLabel = stages.find(s => s.key === stage)?.label || stage;
        logActivity(`Moved task <strong>${deal.title}</strong> from ${oldLabel} → ${newLabel}`, 'orange');
    }

    saveAll();
    renderStageColumn(stage);
    if (changedStage) renderStageColumn(oldStage);
    updateBadges();
    if (currentPage === 'dashboard') renderDashboard();
}

// Move a card to the end of a stage (used for drops on empty column space)
function appendDealToStageEnd(dealId, stage) {
    const deal = deals.find(d => d.id === dealId);
    if (!deal) return;

    const oldStage = deal.stage;
    const changedStage = oldStage !== stage;
    deal.stage = stage;

    deals = deals.filter(d => d.id !== dealId);
    let lastIdx = -1;
    deals.forEach((d, i) => { if (d.stage === stage) lastIdx = i; });
    deals.splice(lastIdx + 1, 0, deal);

    if (changedStage) {
        const oldLabel = stages.find(s => s.key === oldStage)?.label || oldStage;
        const newLabel = stages.find(s => s.key === stage)?.label || stage;
        logActivity(`Moved task <strong>${deal.title}</strong> from ${oldLabel} → ${newLabel}`, 'orange');
    }

    saveAll();
    renderStageColumn(stage);
    if (changedStage) renderStageColumn(oldStage);
    updateBadges();
    if (currentPage === 'dashboard') renderDashboard();
}

// ── Drag & Drop helpers (stage columns) ──

function onColDragStart(e, key) {
    draggingStageKey = key;
    e.stopPropagation();
    const col = e.currentTarget.closest('.kanban-col');
    setTimeout(() => col && col.classList.add('col-dragging'), 0);
    e.dataTransfer.effectAllowed = 'move';
}

function onColDragEnd(e) {
    document.querySelectorAll('.kanban-col').forEach(c => c.classList.remove('col-dragging', 'col-drag-over'));
    draggingStageKey = null;
}

function onColDragOver(e, key) {
    if (!draggingStageKey) return;
    e.preventDefault();
    e.stopPropagation();
    if (key !== draggingStageKey) e.currentTarget.classList.add('col-drag-over');
}

function onColDragLeave(e) {
    if (!draggingStageKey) return;
    e.currentTarget.classList.remove('col-drag-over');
}

function onColDrop(e, key) {
    if (!draggingStageKey) return;
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.remove('col-drag-over');

    const fromKey = draggingStageKey;
    draggingStageKey = null;
    if (fromKey === key) return;

    const fromIdx = stages.findIndex(s => s.key === fromKey);
    const toIdx = stages.findIndex(s => s.key === key);
    if (fromIdx === -1 || toIdx === -1) return;

    const [moved] = stages.splice(fromIdx, 1);
    stages.splice(toIdx, 0, moved);

    saveAll();
    renderKanban();
    toast('Stage order updated.', 'success');
}

